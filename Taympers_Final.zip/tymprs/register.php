<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>TAYMPERS!</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
   <link rel="stylesheet" href='https://fonts.googleapis.com/css?family=Dekko' rel='stylesheet'>
   <link rel="stylesheet" href="style.css">   
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css" />
   <style>
      body {
        background-image: url('img/bg.png'); 
        background-size: cover; 
      }
    </style>

</head>
<body>
<!--header -->
   <header class="header">
      <div class="flex">
         <a href="index.php">
            <img src="img/logo1.png" height="100" alt="Logo">
        </a>
          <nav class="navbar">
              <ul>
                  <li><a href="index.php">HOME</a></li>
                  <li><a href="about.php">ABOUT</a></li>
                  <li><a href="#featured">LIBRARY</a></li>
                  <li><a href="contact.php">CONTACT</a></li>
				  <li><button class="button" id="form-open">ACCOUNT</button></li>
              </ul>
          </nav>
      </div>
  </header>

<!--header -->

<section class="loginreg" id="loginreg">
<!-- forms -->
      <div class="form_container">
		    <!-- REGISTER -->
		    <div class="form signup_form">

          <?php
            if (isset ($_POST["signup"])) {
              $username = $_POST["username"];
              $email= $_POST["email"];
              $password = $_POST["password"];
              $confirmpass = $_POST["confirm_pass"];
              $age = $_POST["age"];

              $passwordHash = password_hash($password, PASSWORD_DEFAULT);
                

              // $errors = array();
              if (empty($username) OR empty($email) OR empty( $password) OR empty($confirmpass) OR empty($age)) {
                echo "<script type='text/javascript'>
                        alert('All fields are required!');
                    </script>";           
              }

              if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                echo    "<script type='text/javascript'>
                                alert('Email is not valid');
                            </script>";
              }

              if (strlen($password)<8) {
                echo    "<script type='text/javascript'>
                                alert('Password must be at least 8 characters long');
                            </script>";
              }

              if ($password !== $confirmpass) {
                echo    "<script type='text/javascript'>
                                alert('Password does not match');
                            </script>"; 
              }

              require_once "database.php";
              $sql = "SELECT * FROM users WHERE email = '$email'";
               $result = mysqli_query($conn, $sql);
              $rowCount = mysqli_num_rows ($result);
              if ($rowCount > 0){
                  echo    "<script type='text/javascript'>
                                alert('Email already exist!');
                            </script>";
              }
              else {

                require_once "database.php";
                $sql = " INSERT INTO users (username, email, password, age) VALUES (?, ?, ?, ?)";
                $stmt = mysqli_stmt_init($conn);
                $prepareStmt = mysqli_stmt_prepare($stmt,$sql);
  
                if ($prepareStmt) {
                  mysqli_stmt_bind_param($stmt, "ssss", $username, $email, $passwordHash, $age);
                  mysqli_stmt_execute($stmt);
                  echo "<script type='text/javascript'>
                        alert('You are registered successfully! You can now log in.')
                        </script>";
  
                }
                else {
                  die("Something went wrong..");
                }
              }

              
            }
          ?>

          <form action="register.php" method="post">
            <h2>Sign-up</h2>

            <div class="input_box">
              <input type="username" name = "username" placeholder="Ilagay ang iyong Username" required />
              <i class="uil uil-lock password"></i>
              <i class="uil uil-eye-slash pw_hide"></i>
            </div>

            <div class="input_box">
              <input type="email" name= "email" placeholder="Ilagay ang iyong email" required />
              <i class="uil uil-envelope-alt email"></i>
            </div>

            <div class="input_box">
              <input type="password" name= "password" placeholder="Lumikha ng password" required />
              <i class="uil uil-lock password"></i>
              <i class="uil uil-eye-slash pw_hide"></i>
            </div>
            <div class="input_box">
              <input type="number" name= "age" placeholder="Ilagay ang iyong edad" required />
              <i class="uil uil-lock password"></i>
              <i class="uil uil-eye-slash pw_hide"></i>
            </div>
        
            <div class="input_box">
              <input type="password" name = "confirm_pass" placeholder="I-confirm ang password" required />
              <i class="uil uil-lock password"></i>
              <i class="uil uil-eye-slash pw_hide"></i>
            </div>

            <button class="button" name="signup" >Sign-up</button>

            <div class="login_signup">Mayroon nang account? <a href="login.php">Log-in</a></div>
          </form>
        </div>
      </div>
<!-- forms -->
</section>



<script src="script.js"></script>
</body>
</html>