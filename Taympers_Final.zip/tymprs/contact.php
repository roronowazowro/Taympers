<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>home</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="style.css">
   <style>
      body {
        background-image: url('img/bg.png'); 
        background-size: cover; 
      }
    </style>

</head>
<body>
<!--header -->
   <header class="header">
      <div class="flex">
         <a href="index.php">
            <img src="img/logo1.png" height="100" alt="Logo">
        </a>
          <nav class="navbar">
              <ul>
                  <li><a href="index.php">HOME</a></li>
                  <li><a href="regform.php">REGISTER</a></li>
                  <li><a href="about.php">ABOUT</a></li>
                  <li><a href="contact.php">CONTACT</a></li>
              </ul>
          </nav>
      </div>
  </header>

<!--header -->

<section class="contact" id="contact">
      <div class="content">
        
      </div>
</section>

<script src="script.js"></script>
</body>
</html>
