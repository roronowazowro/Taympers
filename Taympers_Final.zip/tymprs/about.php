<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>home</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="style.css">
   <style>
      body {
        background-image: url('img/bg.png'); 
        background-size: cover; 
      }
    </style>

</head>
<body>
<!--header -->
   <header class="header">
      <div class="flex">
         <a href="index.php">
            <img src="img/logo1.png" height="100" alt="Logo">
        </a>
          <nav class="navbar">
              <ul>
                  <li><a href="index.php">HOME</a></li>
                  <li><a href="regform.php">REGISTER</a></li>
                  <li><a href="about.php">ABOUT</a></li>
                  <li><a href="contact.php">CONTACT</a></li>
              </ul>
          </nav>
      </div>
  </header>

<!--header -->

<section class="about" id="about">
      <div class="content">
        <h1><img src="img/logo.png" height="200" alt="Logo"> ABOUT</h1>
         <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
            Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure 
            dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat 
            non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
         </p>
      </div>
</section>

<script src="script.js"></script>
</body>
</html>
