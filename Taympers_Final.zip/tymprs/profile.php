<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>TAYMPERS!</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
   <link rel="stylesheet" href='https://fonts.googleapis.com/css?family=Dekko' rel='stylesheet'>
   <link rel="stylesheet" href="style.css">   
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css" />
   <style>
      body {
        background-image: url('img/bg.png'); 
        background-size: cover; 
      }
    </style>

</head>
<body>
<!--header -->
   <header class="header">
      <div class="flex">
         <a href="index.php">
            <img src="img/logo1.png" height="100" alt="Logo">
        </a>
          <nav class="navbar">
              <ul>
                  <li><a href="home.php">HOME</a></li>
                  <li><a href="home.php #about">ABOUT</a></li>
                  <li><a href="library.php">LIBRARY</a></li>
                  <li><a href="home.php #contact">CONTACT</a></li>
				  <li><a href="profile.php"><img src="img/accbtn.png" alt="Account" width="50"></a></li>
              </ul>
          </nav>
      </div>
  </header>

<!--header -->

<section class="deets" id="deets">
<!-- ACCOUNT DEETS -->
 <div class="row">
  <div class="form edit_profile">
          <form action="#">
            <h1>Profile</h1>
			<div class="inputbox">
			<p>Update Username</p>
              <input type="username" placeholder="yourusername"/>
            </div>
            <div class="inputbox">
			<p>Update E-mail</p>
              <input type="e-mail" placeholder="youremail@mail.com"/>
            </div>
            <div class="inputbox">
			<p> Change Password</p>
              <input type="password" placeholder="Enter your password"/>
              <i class="uil uil-eye-slash pw_hide"></i>
            </div>
<br/>
            <button class="button">Update Profile</button>
</div>
</section>



<script src="script.js"></script>
</body>
</html>