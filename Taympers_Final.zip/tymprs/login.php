<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>TAYMPERS!</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
   <link rel="stylesheet" href='https://fonts.googleapis.com/css?family=Dekko' rel='stylesheet'>
   <link rel="stylesheet" href="style.css">   
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css" />
   <style>
      body {
        background-image: url('img/bg.png'); 
        background-size: cover; 
      }
    </style>

</head>
<body>
<!--header -->
   <header class="header">
      <div class="flex">
         <a href="index.php">
            <img src="img/logo1.png" height="100" alt="Logo">
        </a>
          <nav class="navbar">
              <ul>
                  <li><a href="index.php">HOME</a></li>
                  <li><a href="about.php">ABOUT</a></li>
                  <li><a href="#featured">LIBRARY</a></li>
                  <li><a href="contact.php">CONTACT</a></li>
				  <li><button class="button" id="form-open">ACCOUNT</button></li>
              </ul>
          </nav>
      </div>
  </header>

<!--header -->

<section class="loginreg" id="loginreg">
<!-- forms -->
      <div class="form_container">
		<!-- LOGIN -->
        <div class="form login_form">

          <?php
            if (isset($_POST["login"])) {
              $email = $_POST ["email"];
              $password = $_POST["password"];

              require_once "database.php";
              $sql = "SELECT * FROM users WHERE email = '$email'";
              $result = mysqli_query($conn, $sql);
              $user = mysqli_fetch_array($result, MYSQLI_ASSOC);

              if ($user) {
                if (password_verify($password, $user["password"])) {
                  //session_start();
                  $_SESSION["user"] = "yes";
                  header("Location: home.php");
                  die();
                  }
                  else {
                    echo  "<script type='text/javascript'>
                                alert('Password does not match.');
                          </script>";
                  }
              }
              else {
                echo "<script type='text/javascript'>
                      alert('Email does not exist.');
                      </script>";
              }
            }
          ?>

          <form action="login.php" method="post">
            <h2>Login</h2>

            <div class="input_box">
              <input type="email" placeholder="Enter your email" name = "email" required />
              <i class="uil uil-envelope-alt email"></i>
            </div>

            <div class="input_box">
              <input type="password" placeholder="Enter your password" name = "password" required />
              <i class="uil uil-lock password"></i>
              <i class="uil uil-eye-slash pw_hide"></i>
            </div>

            <div class="option_field">
              <span class="checkbox">
                <input type="checkbox" id="check" />
                <label for="check">Huwag akong kalilimutan</label>
              </span>
            </div>

              
            <a href="#" class="forgot_pw">Nalimutan ang iyong password?</a>
            <button class="button" name = "login" >Log-in</button>

            <div class="login_signup">Wala pang account? <a href="register.php">Sign-up</a></div>

          </form>
        </div>
      </div>
<!-- forms -->
</section>



<script src="script.js"></script>
</body>
</html>