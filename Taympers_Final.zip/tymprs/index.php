<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>TAYMPERS!</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
   <link rel="stylesheet" href='https://fonts.googleapis.com/css?family=Dekko' rel='stylesheet'>
   <link rel="stylesheet" href="style.css">   
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css" />
   <style>
      body {
        background-image: url('img/bg.png'); 
        background-size: cover; 
      }
    </style>

</head>
<body>
<!--header -->
   <header class="header">
      <div class="flex">
         <a href="index.php">
            <img src="img/logo1.png" height="100" alt="Logo">
        </a>
          <nav class="navbar">
              <ul>
                  <li><a href="index.php">HOME</a></li>
                  <li><a href="about.php">ABOUT</a></li>
                  <li><a href="#featured">LIBRARY</a></li>
                  <li><a href="contact.php">CONTACT</a></li>
				  <li><a href="register.php">SIGN UP</a></li>
              </ul>
          </nav>
      </div>
  </header>

<!--header -->

<section class="home" id="home">
<!-- content -->
   <div class="row">
      <div class="content">
         <p><img src="img/logo.png" alt="Taympers!"></p>
         <p>Tayo'y pumasok muna sa mundo ng hiwaga-- sa pamamagitan ng pagbabasa.</p>
		 <p><b>Mag-register upang makapagbasa!</b></p>
      </div>
<!-- content -->
<!-- categories -->
      <div class="book-category">
	  <a href="library.php"><img src="img/closed-door.png" width="300"></a>
      </div>
<!-- categories -->
   </div>
</section>

   <!--FEATURED-->
<section class="featured" id="featured">
<div class="row">
<ul>
<button id="fb1"><img src="img/subpage/m2.png"></button>
<button id="fb2"><img src="img/subpage/s1.png"></button>
<button id="fb3"><img src="img/subpage/m3.png"></button>
</ul>
</div>
</section>

   <!--ABOUT-->
<section class="about" id="about">
<div class="row">

</div>
</section>



<script src="script.js"></script>
</body>
</html>